/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { TransferringHospitalLayout, TransferringSubRoute } from './components/transferring/TransferringHospitalLayout';
import { TransferringOverview } from './components/transferring/TransferringOverview';
import { CreateTransferWorkflow } from './components/transferring/CreateTransferWorkflow';
import { ActiveTransfersView } from './components/transferring/ActiveTransfersView';
import { TransferHistoryView } from './components/transferring/TransferHistoryView';

import { ReceivingHospitalLayout, ReceivingSubRoute } from './components/receiving/ReceivingHospitalLayout';
import { ReceivingOverview } from './components/receiving/ReceivingOverview';
import { IncomingTransfersView } from './components/receiving/IncomingTransfersView';
import { AcceptedTransfersView } from './components/receiving/AcceptedTransfersView';
import { ReceivingHistoryView } from './components/receiving/ReceivingHistoryView';

import { EDossierViewer } from './components/EDossierViewer';
import { PdfExportModal } from './components/PdfExportModal';
import { SimulationControls } from './components/SimulationControls';
import { ConsentModal } from './components/ConsentModal';

import { transferService } from './services/transferService';
import { TransferRequestState } from './types/transfer';

export default function App() {
  const [state, setState] = useState<TransferRequestState>(transferService.getState());
  const [currentDashboard, setCurrentDashboard] = useState<'transferring' | 'receiving'>('transferring');
  const [transferringSubRoute, setTransferringSubRoute] = useState<TransferringSubRoute>('overview');
  const [receivingSubRoute, setReceivingSubRoute] = useState<ReceivingSubRoute>('overview');

  // Modals
  const [isPdfOpen, setIsPdfOpen] = useState<boolean>(false);
  const [isSandboxOpen, setIsSandboxOpen] = useState<boolean>(false);
  const [isConsentOpen, setIsConsentOpen] = useState<boolean>(false);
  const [isDossierModalOpen, setIsDossierModalOpen] = useState<boolean>(false);

  // Subscribe to shared state
  useEffect(() => {
    const unsubscribe = transferService.subscribe((newState) => {
      setState(newState);
    });
    return () => unsubscribe();
  }, []);

  // Sync with URL / browser navigation
  useEffect(() => {
    const parseUrl = () => {
      const path = window.location.pathname.toLowerCase();
      if (path.includes('receivinghospital') || path.includes('receiving')) {
        setCurrentDashboard('receiving');
        if (path.includes('incoming')) setReceivingSubRoute('incoming');
        else if (path.includes('accepted')) setReceivingSubRoute('accepted');
        else if (path.includes('history')) setReceivingSubRoute('history');
        else setReceivingSubRoute('overview');
      } else {
        setCurrentDashboard('transferring');
        if (path.includes('create-transfer') || path.includes('create')) setTransferringSubRoute('create-transfer');
        else if (path.includes('active-transfers') || path.includes('active')) setTransferringSubRoute('active-transfers');
        else if (path.includes('history')) setTransferringSubRoute('history');
        else setTransferringSubRoute('overview');
      }
    };

    parseUrl();
    window.addEventListener('popstate', parseUrl);
    return () => window.removeEventListener('popstate', parseUrl);
  }, []);

  const updateUrl = (dashboard: 'transferring' | 'receiving', sub: string) => {
    const path = `/${dashboard}hospital${sub === 'overview' ? '' : `/${sub}`}`;
    try {
      window.history.pushState({}, '', path);
    } catch {
      // ignore in iframe
    }
  };

  const navigateTransferring = (route: TransferringSubRoute) => {
    setTransferringSubRoute(route);
    updateUrl('transferring', route);
  };

  const navigateReceiving = (route: ReceivingSubRoute) => {
    setReceivingSubRoute(route);
    updateUrl('receiving', route);
  };

  const switchToReceiving = () => {
    setCurrentDashboard('receiving');
    setReceivingSubRoute('overview');
    updateUrl('receiving', 'overview');
  };

  const switchToTransferring = () => {
    setCurrentDashboard('transferring');
    setTransferringSubRoute('overview');
    updateUrl('transferring', 'overview');
  };

  // State actions
  const handleSelectHospital = (hospitalId: string) => {
    transferService.selectDestinationHospital(hospitalId);
  };

  const handleGenerateDossier = () => {
    transferService.generateEDossier();
  };

  const handleAuthorizeConsent = (
    isEmergencyOverride: boolean,
    overrideData?: { staffName: string; staffReg: string; reason: string }
  ) => {
    setIsConsentOpen(false);
    transferService.validateConsent(isEmergencyOverride, overrideData);
  };

  const handleSendTransferRequest = () => {
    transferService.sendTransferRequest();
  };

  const handleAcceptTransfer = (notes?: string) => {
    transferService.acceptTransfer(notes);
    transferService.dispatchAmbulance();
    setReceivingSubRoute('accepted');
  };

  const handleUpdateTransitProgress = (percent: number) => {
    transferService.updateTransitProgress(percent);
  };

  const handleResetDemo = () => {
    transferService.resetDemo();
    setCurrentDashboard('transferring');
    setTransferringSubRoute('overview');
    setReceivingSubRoute('overview');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans antialiased selection:bg-red-600 selection:text-white">
      {/* DASHBOARD 1: TRANSFERRING HOSPITAL (KANPUR ER) */}
      {currentDashboard === 'transferring' && (
        <TransferringHospitalLayout
          currentSubRoute={transferringSubRoute}
          onNavigate={navigateTransferring}
          onSwitchToReceiving={switchToReceiving}
          onOpenSandbox={() => setIsSandboxOpen(true)}
          state={state}
        >
          {transferringSubRoute === 'overview' && (
            <TransferringOverview
              state={state}
              onInitiateTransfer={() => navigateTransferring('create-transfer')}
              onViewActiveTransfer={() => navigateTransferring('active-transfers')}
              onViewDossier={() => setIsDossierModalOpen(true)}
              onOpenPdf={() => setIsPdfOpen(true)}
              onSwitchToReceiving={switchToReceiving}
            />
          )}

          {transferringSubRoute === 'create-transfer' && (
            <CreateTransferWorkflow
              state={state}
              onSelectHospital={handleSelectHospital}
              onGenerateDossier={handleGenerateDossier}
              onAuthorizeConsent={handleAuthorizeConsent}
              onSendTransferRequest={handleSendTransferRequest}
              onOpenPdf={() => setIsPdfOpen(true)}
              onSwitchToReceiving={switchToReceiving}
            />
          )}

          {transferringSubRoute === 'active-transfers' && (
            <ActiveTransfersView
              state={state}
              onViewDossier={() => setIsDossierModalOpen(true)}
              onTrackTransit={() => {}}
              onSwitchToReceiving={switchToReceiving}
              onUpdateTransitProgress={handleUpdateTransitProgress}
            />
          )}

          {transferringSubRoute === 'history' && (
            <TransferHistoryView
              state={state}
              onOpenPdf={() => setIsPdfOpen(true)}
            />
          )}
        </TransferringHospitalLayout>
      )}

      {/* DASHBOARD 2: RECEIVING HOSPITAL (SGPGI LUCKNOW) */}
      {currentDashboard === 'receiving' && (
        <ReceivingHospitalLayout
          currentSubRoute={receivingSubRoute}
          onNavigate={navigateReceiving}
          onSwitchToTransferring={switchToTransferring}
          onOpenSandbox={() => setIsSandboxOpen(true)}
          state={state}
        >
          {receivingSubRoute === 'overview' && (
            <ReceivingOverview
              state={state}
              onReviewTransfer={() => navigateReceiving('incoming')}
              onViewDossier={() => setIsDossierModalOpen(true)}
              onAcceptTransfer={() => handleAcceptTransfer()}
              onTrackAmbulance={() => navigateReceiving('accepted')}
              onViewResources={() => navigateReceiving('accepted')}
            />
          )}

          {receivingSubRoute === 'incoming' && (
            <IncomingTransfersView
              state={state}
              onAcceptTransfer={() => handleAcceptTransfer()}
              onTrackAmbulance={() => navigateReceiving('accepted')}
              onOpenPdf={() => setIsPdfOpen(true)}
            />
          )}

          {receivingSubRoute === 'accepted' && (
            <AcceptedTransfersView
              state={state}
              onTrackAmbulance={() => {}}
              onViewDossier={() => setIsDossierModalOpen(true)}
              onUpdateTransitProgress={handleUpdateTransitProgress}
            />
          )}

          {receivingSubRoute === 'history' && (
            <ReceivingHistoryView
              state={state}
              onOpenPdf={() => setIsPdfOpen(true)}
            />
          )}
        </ReceivingHospitalLayout>
      )}

      {/* Shared E-Dossier Inspect Modal */}
      {isDossierModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-2xl max-w-4xl w-full border border-slate-200 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="font-bold text-sm">Clinical E-Dossier Inspection (FHIR R4 Bundle)</div>
              <button
                onClick={() => setIsDossierModalOpen(false)}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg cursor-pointer"
              >
                Close
              </button>
            </div>
            <div className="p-6 overflow-y-auto">
              <EDossierViewer
                state={state}
                onOpenPdf={() => setIsPdfOpen(true)}
                onProceedToConsent={() => {
                  setIsDossierModalOpen(false);
                  if (currentDashboard === 'transferring') {
                    navigateTransferring('create-transfer');
                  }
                }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Printable PDF Modal */}
      <PdfExportModal
        isOpen={isPdfOpen}
        state={state}
        onClose={() => setIsPdfOpen(false)}
      />

      {/* Consent Modal */}
      <ConsentModal
        isOpen={isConsentOpen}
        state={state}
        onClose={() => setIsConsentOpen(false)}
        onAuthorizeConsent={handleAuthorizeConsent}
      />

      {/* Simulation Sandbox Drawer */}
      <SimulationControls
        isOpen={isSandboxOpen}
        state={state}
        onClose={() => setIsSandboxOpen(false)}
        onSimulateError={(type) => transferService.simulateError(type)}
        onResolveError={() => transferService.resolveError()}
        onFastForwardAcceptance={() => {
          transferService.acceptTransfer();
          setCurrentDashboard('receiving');
          setReceivingSubRoute('accepted');
        }}
        onFastForwardDispatch={() => {
          transferService.dispatchAmbulance();
          if (currentDashboard === 'transferring') {
            setTransferringSubRoute('active-transfers');
          } else {
            setReceivingSubRoute('accepted');
          }
        }}
        onReset={handleResetDemo}
        onOpenPdf={() => setIsPdfOpen(true)}
      />
    </div>
  );
}
